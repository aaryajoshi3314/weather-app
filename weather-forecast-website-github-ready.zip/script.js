const els = {
  city: document.querySelector("#cityInput"),
  search: document.querySelector("#searchBtn"),
  locate: document.querySelector("#locationBtn"),
  status: document.querySelector("#status"),
  weather: document.querySelector("#weather"),
  place: document.querySelector("#place"),
  temp: document.querySelector("#temperature"),
  condition: document.querySelector("#condition"),
  feels: document.querySelector("#feelsLike"),
  updated: document.querySelector("#updated"),
  icon: document.querySelector("#weatherIcon"),
  humidity: document.querySelector("#humidity"),
  wind: document.querySelector("#wind"),
  rain: document.querySelector("#rain"),
  pressure: document.querySelector("#pressure"),
  visibility: document.querySelector("#visibility"),
  uv: document.querySelector("#uv"),
  hourly: document.querySelector("#hourly"),
  daily: document.querySelector("#daily")
};

const WMO = {
  0:["Clear sky","☀️"], 1:["Mainly clear","🌤️"], 2:["Partly cloudy","⛅"], 3:["Overcast","☁️"],
  45:["Fog","🌫️"], 48:["Rime fog","🌫️"], 51:["Light drizzle","🌦️"], 53:["Drizzle","🌦️"], 55:["Heavy drizzle","🌧️"],
  56:["Freezing drizzle","🌧️"], 57:["Freezing drizzle","🌧️"], 61:["Light rain","🌦️"], 63:["Rain","🌧️"], 65:["Heavy rain","🌧️"],
  66:["Freezing rain","🌧️"], 67:["Heavy freezing rain","🌧️"], 71:["Light snow","🌨️"], 73:["Snow","❄️"], 75:["Heavy snow","❄️"],
  77:["Snow grains","❄️"], 80:["Rain showers","🌦️"], 81:["Rain showers","🌧️"], 82:["Heavy showers","⛈️"],
  85:["Snow showers","🌨️"], 86:["Heavy snow showers","❄️"], 95:["Thunderstorm","⛈️"], 96:["Thunderstorm + hail","⛈️"], 99:["Severe thunderstorm","⛈️"]
};

function weatherInfo(code) { return WMO[code] || ["Unknown","🌡️"]; }
function setStatus(msg, error=false) {
  els.status.textContent = msg;
  els.status.style.color = error ? "#fda4af" : "";
}
function fmtTime(iso) {
  return new Intl.DateTimeFormat(undefined, {hour:"numeric", minute:"2-digit"}).format(new Date(iso));
}
function fmtDay(iso) {
  return new Intl.DateTimeFormat(undefined, {weekday:"long"}).format(new Date(iso + "T12:00:00"));
}
function fmtDate(iso) {
  return new Intl.DateTimeFormat(undefined, {day:"numeric", month:"short"}).format(new Date(iso + "T12:00:00"));
}

async function geocode(city) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Location search failed.");
  const data = await res.json();
  if (!data.results?.length) throw new Error("City not found. Try another city name.");
  return data.results[0];
}

async function getWeather(lat, lon, label) {
  const params = new URLSearchParams({
    latitude: lat, longitude: lon, timezone:"auto",
    forecast_days:"7",
    current:"temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,surface_pressure,wind_speed_10m",
    hourly:"temperature_2m,precipitation_probability,weather_code,visibility,uv_index,wind_speed_10m",
    daily:"weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,uv_index_max"
  });
  const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`);
  if (!res.ok) throw new Error("Weather service unavailable.");
  const data = await res.json();
  render(data, label);
}

function render(data, label) {
  const c = data.current, h = data.hourly, d = data.daily;
  const [condition, icon] = weatherInfo(c.weather_code);
  els.place.textContent = label;
  els.temp.textContent = `${Math.round(c.temperature_2m)}°`;
  els.condition.textContent = condition;
  els.feels.textContent = `Feels like ${Math.round(c.apparent_temperature)}°`;
  els.updated.textContent = `Updated ${fmtTime(c.time)}`;
  els.icon.textContent = icon;
  els.humidity.textContent = `${Math.round(c.relative_humidity_2m)}%`;
  els.wind.textContent = `${Math.round(c.wind_speed_10m)} km/h`;
  els.rain.textContent = `${Number(c.precipitation).toFixed(1)} mm`;
  els.pressure.textContent = `${Math.round(c.surface_pressure)} hPa`;

  const currentIndex = Math.max(0, h.time.findIndex(t => t >= c.time));
  const end = Math.min(currentIndex + 12, h.time.length);
  const vis = h.visibility?.[currentIndex] ?? null;
  els.visibility.textContent = vis == null ? "-- km" : `${(vis/1000).toFixed(1)} km`;
  els.uv.textContent = h.uv_index?.[currentIndex] != null ? Number(h.uv_index[currentIndex]).toFixed(1) : "--";

  els.hourly.innerHTML = "";
  for (let i=currentIndex; i<end; i++) {
    const [desc, ic] = weatherInfo(h.weather_code[i]);
    els.hourly.insertAdjacentHTML("beforeend", `
      <div class="hour-card">
        <div class="time">${i === currentIndex ? "Now" : fmtTime(h.time[i])}</div>
        <div class="icon" title="${desc}">${ic}</div>
        <strong>${Math.round(h.temperature_2m[i])}°</strong>
        <small>${h.precipitation_probability[i] ?? 0}% rain</small>
      </div>`);
  }

  els.daily.innerHTML = "";
  for (let i=0; i<d.time.length; i++) {
    const [desc, ic] = weatherInfo(d.weather_code[i]);
    els.daily.insertAdjacentHTML("beforeend", `
      <div class="day-row">
        <div><div class="day-name">${i === 0 ? "Today" : fmtDay(d.time[i])}</div><div class="day-date">${fmtDate(d.time[i])}</div></div>
        <div class="day-weather"><span class="day-icon">${ic}</span><span>${desc}</span></div>
        <div class="rain-chance">💧 ${d.precipitation_probability_max[i] ?? 0}% • ${Number(d.precipitation_sum[i] ?? 0).toFixed(1)} mm</div>
        <div class="temps">${Math.round(d.temperature_2m_max[i])}° <span>${Math.round(d.temperature_2m_min[i])}°</span></div>
      </div>`);
  }
  els.weather.classList.remove("hidden");
}

async function searchCity() {
  const city = els.city.value.trim();
  if (!city) return setStatus("Enter a city name first.", true);
  setStatus("Loading live weather...");
  try {
    const place = await geocode(city);
    const label = [place.name, place.admin1, place.country].filter(Boolean).join(", ");
    await getWeather(place.latitude, place.longitude, label);
    setStatus("Live forecast loaded.");
  } catch (err) {
    setStatus(err.message, true);
  }
}

function useLocation() {
  if (!navigator.geolocation) return setStatus("Your browser does not support location.", true);
  setStatus("Getting your location...");
  navigator.geolocation.getCurrentPosition(async pos => {
    try {
      await getWeather(pos.coords.latitude, pos.coords.longitude, "Your current location");
      setStatus("Live forecast loaded.");
    } catch (err) { setStatus(err.message, true); }
  }, () => setStatus("Location permission was denied. Search for a city instead.", true), {enableHighAccuracy:true, timeout:10000});
}

els.search.addEventListener("click", searchCity);
els.city.addEventListener("keydown", e => { if (e.key === "Enter") searchCity(); });
els.locate.addEventListener("click", useLocation);

searchCityByDefault();
async function searchCityByDefault() {
  els.city.value = "Jaipur";
  await searchCity();
}
