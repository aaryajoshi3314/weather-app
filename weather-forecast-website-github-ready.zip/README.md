# SkyCast — Weather Forecast Website

A responsive, real-time weather forecast website built with plain HTML, CSS and JavaScript.

## Features

- Live current weather
- City search
- Use device location
- Next 12 hours
- 7-day forecast
- Humidity, wind, rain, pressure, visibility and UV
- Responsive mobile design
- No API key required

## Weather API

This project uses Open-Meteo for geocoding and weather forecast data.

## Run locally

Simply open `index.html` in a modern browser.

For best results, serve the folder with a local web server because browser location permissions can be stricter for local files.

## GitHub Pages

1. Create a public GitHub repository named `weather-forecast-website`.
2. Upload all project files.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions**.
5. The included workflow will publish the website.

Your site will normally be available at:

`https://YOUR-USERNAME.github.io/weather-forecast-website/`

## Files

- `index.html` — website structure
- `style.css` — responsive design
- `script.js` — weather API and interactions
- `.github/workflows/deploy.yml` — automatic GitHub Pages deployment
